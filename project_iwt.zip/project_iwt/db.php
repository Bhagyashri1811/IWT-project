<?php
$con = mysqli_connect("localhost","root","","iwt") or die(mysql_error());

?>